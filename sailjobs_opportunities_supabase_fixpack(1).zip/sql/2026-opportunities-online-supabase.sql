-- SailJobs LATAM
-- Paquete: oportunidades online en Supabase.
-- Ejecutar en Supabase SQL Editor antes de probar oportunidades online.

create extension if not exists pgcrypto;

create table if not exists public.opportunities (
    id uuid primary key default gen_random_uuid(),
    legacy_id text,
    title text not null default 'Oportunidad sin título',
    category text,
    club_id uuid references public.clubs(id) on delete set null,
    club_name text,
    organization_id uuid references public.clubs(id) on delete set null,
    organization_name text,
    owner_type text,
    owner_id uuid references public.clubs(id) on delete set null,
    owner_name text,
    created_by uuid references auth.users(id) on delete set null,
    updated_by uuid references auth.users(id) on delete set null,
    opportunity_type text not null default 'employment',
    compensation_type text not null default 'to_confirm',
    compensation_details text,
    salary text,
    country text,
    country_code text,
    state text,
    state_code text,
    city text,
    city_name text,
    duration text,
    openings integer not null default 1,
    application_deadline date,
    event_id uuid references public.events(id) on delete set null,
    eligible_profiles text[] not null default array['professional']::text[],
    description text,
    requirements text[] not null default '{}'::text[],
    apply_link text,
    website text,
    status text not null default 'active',
    moderation_reason text,
    moderated_at timestamptz,
    metadata jsonb not null default '{}'::jsonb,
    created_at timestamptz not null default now(),
    updated_at timestamptz
);

alter table public.opportunities add column if not exists legacy_id text;
alter table public.opportunities add column if not exists category text;
alter table public.opportunities add column if not exists club_id uuid references public.clubs(id) on delete set null;
alter table public.opportunities add column if not exists club_name text;
alter table public.opportunities add column if not exists organization_id uuid references public.clubs(id) on delete set null;
alter table public.opportunities add column if not exists organization_name text;
alter table public.opportunities add column if not exists owner_type text;
alter table public.opportunities add column if not exists owner_id uuid references public.clubs(id) on delete set null;
alter table public.opportunities add column if not exists owner_name text;
alter table public.opportunities add column if not exists created_by uuid references auth.users(id) on delete set null;
alter table public.opportunities add column if not exists updated_by uuid references auth.users(id) on delete set null;
alter table public.opportunities add column if not exists opportunity_type text not null default 'employment';
alter table public.opportunities add column if not exists compensation_type text not null default 'to_confirm';
alter table public.opportunities add column if not exists compensation_details text;
alter table public.opportunities add column if not exists salary text;
alter table public.opportunities add column if not exists country text;
alter table public.opportunities add column if not exists country_code text;
alter table public.opportunities add column if not exists state text;
alter table public.opportunities add column if not exists state_code text;
alter table public.opportunities add column if not exists city text;
alter table public.opportunities add column if not exists city_name text;
alter table public.opportunities add column if not exists duration text;
alter table public.opportunities add column if not exists openings integer not null default 1;
alter table public.opportunities add column if not exists application_deadline date;
alter table public.opportunities add column if not exists event_id uuid references public.events(id) on delete set null;
alter table public.opportunities add column if not exists eligible_profiles text[] not null default array['professional']::text[];
alter table public.opportunities add column if not exists description text;
alter table public.opportunities add column if not exists requirements text[] not null default '{}'::text[];
alter table public.opportunities add column if not exists apply_link text;
alter table public.opportunities add column if not exists website text;
alter table public.opportunities add column if not exists status text not null default 'active';
alter table public.opportunities add column if not exists moderation_reason text;
alter table public.opportunities add column if not exists moderated_at timestamptz;
alter table public.opportunities add column if not exists metadata jsonb not null default '{}'::jsonb;
alter table public.opportunities add column if not exists created_at timestamptz not null default now();
alter table public.opportunities add column if not exists updated_at timestamptz;

update public.opportunities
set
    status = case
        when status is null or status = '' then 'active'
        when status in ('inactive', 'deleted', 'removed') then 'hidden'
        else status
    end,
    opportunity_type = coalesce(nullif(opportunity_type, ''), 'employment'),
    compensation_type = coalesce(nullif(compensation_type, ''), 'to_confirm'),
    openings = coalesce(openings, 1),
    eligible_profiles = coalesce(eligible_profiles, array['professional']::text[]),
    requirements = coalesce(requirements, '{}'::text[]),
    metadata = coalesce(metadata, '{}'::jsonb)
where true;

create index if not exists opportunities_status_created_idx
on public.opportunities(status, created_at desc);

create index if not exists opportunities_owner_idx
on public.opportunities(owner_id, organization_id, club_id);

create index if not exists opportunities_event_idx
on public.opportunities(event_id);

create unique index if not exists opportunities_legacy_unique_idx
on public.opportunities(legacy_id)
where legacy_id is not null;

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
    new.updated_at = now();
    return new;
end;
$$;

drop trigger if exists set_opportunities_updated_at on public.opportunities;

create trigger set_opportunities_updated_at
before update on public.opportunities
for each row
execute function public.set_updated_at();

alter table public.opportunities enable row level security;

drop policy if exists "opportunities_select_public" on public.opportunities;
drop policy if exists "opportunities_insert_authenticated" on public.opportunities;
drop policy if exists "opportunities_update_authenticated" on public.opportunities;
drop policy if exists "opportunities_delete_superadmin" on public.opportunities;

create policy "opportunities_select_public"
on public.opportunities
for select
to anon, authenticated
using (true);

-- RLS beta: la validación fina de permisos todavía queda en la app.
-- Más adelante conviene endurecer esto con funciones can_manage_opportunity/can_moderate_content en SQL.
create policy "opportunities_insert_authenticated"
on public.opportunities
for insert
to authenticated
with check (true);

create policy "opportunities_update_authenticated"
on public.opportunities
for update
to authenticated
using (true)
with check (true);

create policy "opportunities_delete_superadmin"
on public.opportunities
for delete
to authenticated
using (public.is_superadmin(auth.uid()));

grant select on public.opportunities to anon, authenticated;
grant insert, update, delete on public.opportunities to authenticated;
