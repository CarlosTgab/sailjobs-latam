# SailJobs LATAM — Oportunidades en Supabase

Este paquete migra el flujo de oportunidades para que las publicaciones, ediciones y moderaciones puedan guardarse en Supabase y verse online por todos los testers.

## Archivos incluidos

- `src/utils/jobsStorage.js`
- `src/components/JobsSync.jsx`
- `src/App.jsx`
- `src/pages/Jobs.jsx`
- `src/pages/JobDetail.jsx`
- `src/pages/CreateJob.jsx`
- `src/pages/EditJob.jsx`
- `src/pages/AdminJobs.jsx`
- `src/pages/AdminDashboard.jsx`
- `src/pages/Home.jsx`
- `src/pages/ClubDashboard.jsx`
- `src/pages/OrganizationAdminDashboard.jsx`
- `sql/2026-opportunities-online-supabase.sql`

## Qué cambia

- Las oportunidades nuevas se guardan en `public.opportunities`.
- `/jobs` sincroniza oportunidades desde Supabase.
- El detalle y edición de oportunidades pueden cargar oportunidades remotas.
- El superadmin puede dar de baja/restaurar oportunidades de forma online.
- Los paneles de club, organización, home y admin sincronizan oportunidades.
- Sigue habiendo caché local como fallback si Supabase falla, pero la fuente real pasa a ser Supabase.

## Cómo aplicar

Desde la raíz del proyecto:

```powershell
Expand-Archive -Path .\sailjobs_opportunities_supabase_fixpack.zip -DestinationPath . -Force
```

Después, en Supabase SQL Editor, ejecutar completo:

```text
sql/2026-opportunities-online-supabase.sql
```

Luego:

```powershell
npm run build
npm run dev
```

## Prueba recomendada

1. Entrar como club.
2. Publicar una oportunidad.
3. Abrir `/jobs` en otro navegador/incógnito.
4. Verificar que la oportunidad aparece.
5. Entrar como superadmin.
6. Ir a `/admin/jobs`.
7. Dar de baja la oportunidad.
8. Verificar que desaparece de `/jobs`.
9. Restaurarla desde `/admin/jobs`.
10. Verificar que vuelve a aparecer.

## Después de probar local

```powershell
git status
git add .
git commit -m "Migrar oportunidades a Supabase"
git push
```

Vercel redeploya y los testers deberían ver las oportunidades online.
